package base;
import java.util.Scanner;
import java.util.Arrays;
public class Main {
    static Scanner console = new Scanner(System.in);

    public static void main(String[] args) {

        //while loop
        int x = 3;
        while (x > 1) {
            System.out.println(x);
            x--;
        }
        //for loop - even numbers
        for (int i = 0; i <= 10; i = i + 2) {
            System.out.println(i);
        }

        //switch case
        int team = 6;
        String teamString = null;
        switch (team) {
            case 1:
                teamString = "Rams";
                break;
            case 2:
                teamString = "Bengals";
                break;
            case 3:
                teamString = "Chiefs";
                break;
            case 4:
                teamString = "49ers";
                break;
            case 5:
                teamString = "Bills";
                break;
            case 6:
                teamString = "Buccaneers";
                break;
            case 7:
                teamString = "Packers";
                break;
            case 8:
                teamString = "Titans";
                break;
        }
        System.out.println(teamString);

        //exponent user input
        Scanner exp = new Scanner(System.in);
        double num1, num2;
        System.out.print("Enter first number (base): ");
        num1 = exp.nextDouble();
        System.out.print("Enter second number (exponent): ");
        num2 = exp.nextDouble();


        System.out.println(Math.pow(num1, num2));


        //Amount of numbers in array
        String str;
        int i, length, counter[] = new int[500];

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter any combination of numbers. Press enter to submit array.");
        str = scanner.nextLine();
        length = str.length();

        for (i = 0; i < length; i++) {
            counter[(int) str.charAt(i)]++;
        }

        for (i = 0; i < 500; i++) {
            if (counter[i] != 0) {
                System.out.println((char) i + " --> " + counter[i]);
            }
        }

        //Summation Array
        System.out.println("Enter length of array:");
        Scanner s = new Scanner(System.in);
        int size = s.nextInt();
        int summationArray[] = new int [size];
        int sum = 0;
        System.out.println("Enter the elements of the array, press enter following each integer/input.");

        for(int q=0; q<size; q++){
            summationArray[q] = s.nextInt();
            sum = sum + summationArray[q];
        }
        System.out.println("Array elements are: "+Arrays.toString(summationArray));
        System.out.println("Sum of elements within array are: "+sum);

        //Pythagorean theorem
        Scanner pyth = new Scanner(System.in);
        double line1, line2, hypotenuse;

        System.out.print("Enter first line value: ");
        line1 = pyth.nextDouble();
        System.out.print("Enter second line value: ");
        line2 = pyth.nextDouble();
        hypotenuse = Math.sqrt(Math.pow(line1, 2) + Math.pow(line2, 2));

        System.out.println("The hypotenuse of the triangle is: "+hypotenuse);

        /**Was not sure how to replicate already used exponent function while incorporating
         the division and addition functions. So, this recycles exponential function from line 63**/
    }

    
}


